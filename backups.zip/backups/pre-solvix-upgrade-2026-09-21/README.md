# Salman Solar Energy — premium website

A premium responsive solar-technology catalog and business website for Salman Solar Energy in Sialkot. The upgrade preserves the existing branding, catalog, pricing, forms, product galleries, calculator, business information, Maps links, WhatsApp enquiries and official social links.

## Run locally

```bash
python3 -m http.server 4173 --bind 0.0.0.0
```

Open `http://localhost:4173`.

## Preserved functionality

- User-supplied opening banner and refined header logo
- Existing catalog with all product collections and product cards
- Two product views, product detail modal and product-specific WhatsApp enquiry
- Existing bill calculator and WhatsApp quotation form
- Exact supplied Google Maps links for both branches
- Exact Instagram, TikTok, YouTube and Facebook links
- Direct WhatsApp number `0300 6122109` using `923006122109`

## Premium design upgrade

- Two-level glass sticky navigation with mega-menu, product search and active navigation states
- Sophisticated solar-blue, energy-green and sunlight-orange gradients
- Animated energy field, grid patterns, glow layers and lightweight particles
- Cinematic banner framing with pointer depth and parallax-style interaction
- Premium service cards with subtle 3D hover lift
- Scroll-reveal motion with staggered timing
- Interactive buttons, icons, cards and image zoom effects
- Compact header transition while scrolling
- Reduced-motion accessibility support

## Added professional sections

- Premium Services
- AMWAH Solar Care process, integrated with Salman Solar Energy:
  - Report Problem
  - Expert Review
  - Technician Assigned
  - Problem Solved
- Direct Solar Care problem-report form with WhatsApp handoff
- Customer review form with WhatsApp and Google review access
- Clickable opening-banner collection shortcuts that activate the selected catalog collection
- AI Solar Advisor for English and common Roman Urdu requirements
- Dedicated Buy Now flow
- Solar Solutions Showcase with animated category filters
- Animated business counters
- Google-review testimonial carousel
- Animated FAQ accordion
- Enhanced contact CTA and premium footer

## Smart tools

- Product search by brand, model, category or price
- AI-assisted system starting point based on bill, property type, AC load and backup requirement
- Suggested system capacity, panel quantity, inverter class, battery starting point and daytime generation
- AI recommendation can be sent directly to WhatsApp
- Calculator now includes an animated capacity gauge, approximate panel count and generation indicator

## Direct links

- Main branch: `https://maps.app.goo.gl/Dar3N7er2mgjLBZ46`
- Branch 2: `https://maps.app.goo.gl/c9w2uToPFhjLqt1V8`
- WhatsApp: `https://wa.me/923006122109`
- YouTube: `https://youtube.com/@salmansolarenergy?si=HOHQI3OfkzgUZr8h`
- TikTok: `https://www.tiktok.com/@salmansolarenergy?_r=1&_t=ZS-99tOpoESY8O`
- Instagram: `https://www.instagram.com/salman_solar_energy?stkn=MXBiZnRheHV0N2FkdQ==`
- Facebook: `https://www.facebook.com/share/1DDQQQ9z7t/`

## Important note

AI guidance, calculator results and prices are indicative. Final system sizing, product model, stock, rate, specification, installation requirement and warranty must be confirmed with Salman Solar Energy.
